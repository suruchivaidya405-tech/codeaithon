package com.permian.metrics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetricsApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(MetricsApiApplication.class, args);
    }
}
