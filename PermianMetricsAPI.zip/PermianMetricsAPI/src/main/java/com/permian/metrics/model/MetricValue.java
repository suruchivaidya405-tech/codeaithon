package com.permian.metrics.model;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "metric_value", schema = "cait_dev")
public class MetricValue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "metric_value_id")
    private Long metricValueId;

    @Column(name = "company_id", nullable = false)
    private Integer companyId;

    @Column(name = "source_document_id", nullable = false)
    private Integer sourceDocumentId;

    @Column(name = "metric_id", nullable = false)
    private Integer metricId;

    @Column(name = "extracted_metric_value")
    private BigDecimal extractedMetricValue;

    @Column(name = "extracted_metric_unit")
    private String extractedMetricUnit;

    @Column(name = "metric_value")
    private Double metricValue;

    @Column(name = "unit")
    private String unit;

    @Column(name = "period_start_date")
    private LocalDate periodStartDate;

    @Column(name = "period_end_date")
    private LocalDate periodEndDate;

    @Column(name = "segment_name")
    private String segmentName;

    @Column(name = "basin_name")
    private String basinName;

    @Column(name = "extraction_method")
    private String extractionMethod;

    @Column(name = "extraction_confidence_score")
    private BigDecimal extractionConfidenceScore;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    // Constructors
    public MetricValue() {}

    public MetricValue(Integer companyId, Integer sourceDocumentId, Integer metricId,
                       BigDecimal extractedMetricValue, String extractedMetricUnit,
                       Double metricValue, String unit, LocalDate periodStartDate, LocalDate periodEndDate,
                       String segmentName, String basinName, String extractionMethod, BigDecimal extractionConfidenceScore) {
        this.companyId = companyId;
        this.sourceDocumentId = sourceDocumentId;
        this.metricId = metricId;
        this.extractedMetricValue = extractedMetricValue;
        this.extractedMetricUnit = extractedMetricUnit;
        this.metricValue = metricValue;
        this.unit = unit;
        this.periodStartDate = periodStartDate;
        this.periodEndDate = periodEndDate;
        this.segmentName = segmentName;
        this.basinName = basinName;
        this.extractionMethod = extractionMethod;
        this.extractionConfidenceScore = extractionConfidenceScore;
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getMetricValueId() { return metricValueId; }
    public void setMetricValueId(Long metricValueId) { this.metricValueId = metricValueId; }

    public Integer getCompanyId() { return companyId; }
    public void setCompanyId(Integer companyId) { this.companyId = companyId; }

    public Integer getSourceDocumentId() { return sourceDocumentId; }
    public void setSourceDocumentId(Integer sourceDocumentId) { this.sourceDocumentId = sourceDocumentId; }

    public Integer getMetricId() { return metricId; }
    public void setMetricId(Integer metricId) { this.metricId = metricId; }

    public BigDecimal getExtractedMetricValue() { return extractedMetricValue; }
    public void setExtractedMetricValue(BigDecimal extractedMetricValue) { this.extractedMetricValue = extractedMetricValue; }

    public String getExtractedMetricUnit() { return extractedMetricUnit; }
    public void setExtractedMetricUnit(String extractedMetricUnit) { this.extractedMetricUnit = extractedMetricUnit; }

    public Double getMetricValue() { return metricValue; }
    public void setMetricValue(Double metricValue) { this.metricValue = metricValue; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public LocalDate getPeriodStartDate() { return periodStartDate; }
    public void setPeriodStartDate(LocalDate periodStartDate) { this.periodStartDate = periodStartDate; }

    public LocalDate getPeriodEndDate() { return periodEndDate; }
    public void setPeriodEndDate(LocalDate periodEndDate) { this.periodEndDate = periodEndDate; }

    public String getSegmentName() { return segmentName; }
    public void setSegmentName(String segmentName) { this.segmentName = segmentName; }

    public String getBasinName() { return basinName; }
    public void setBasinName(String basinName) { this.basinName = basinName; }

    public String getExtractionMethod() { return extractionMethod; }
    public void setExtractionMethod(String extractionMethod) { this.extractionMethod = extractionMethod; }

    public BigDecimal getExtractionConfidenceScore() { return extractionConfidenceScore; }
    public void setExtractionConfidenceScore(BigDecimal extractionConfidenceScore) { this.extractionConfidenceScore = extractionConfidenceScore; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
