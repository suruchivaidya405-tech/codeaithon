package com.permian.metrics.controller;

import com.permian.metrics.model.MetricValue;

import com.permian.metrics.repository.MetricValueRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class MetricController {

    private static final Logger logger = LoggerFactory.getLogger(MetricController.class);



    @Autowired
    private MetricValueRepository metricValueRepository;

    @GetMapping("/metric-values")
    public List<MetricValue> getMetricValues() {
        logger.info("GET /metric-values called");
        List<MetricValue> metricValues = metricValueRepository.findAll();
        logger.info("Fetched {} metric values", metricValues.size());
        return metricValues;
    }

    @PostMapping("/metric-values")
    @Transactional
    public ResponseEntity<String> postMetricValues(@RequestBody Map<String, Object> jsonData) {
        logger.info("POST /metric-values called with json data");
        try {
            List<Map<String, Object>> categories = (List<Map<String, Object>>) jsonData.get("categories");
            List<MetricValue> metricValues = new ArrayList<>();
            for (Map<String, Object> category : categories) {
                List<Map<String, Object>> metrics = (List<Map<String, Object>>) category.get("metrics");
                for (Map<String, Object> metric : metrics) {
                    Double value = (Double) metric.get("value");
                    if (value != null) {
                        MetricValue metricValue = new MetricValue(
                            1, // companyId - set to 1 to avoid null constraint
                            1, // sourceDocumentId - set to 1 to avoid null constraint
                            1, // metricId - set to 1 to avoid null constraint
                            BigDecimal.valueOf(value), // extractedMetricValue
                            (String) metric.get("unit"), // extractedMetricUnit
                            value, // metricValue
                            (String) metric.get("unit"), // unit
                            LocalDate.of(2024, 4, 1), // periodStartDate
                            LocalDate.of(2024, 6, 30), // periodEndDate
                            null, // segmentName
                            null, // basinName
                            "extracted", // extractionMethod
                            BigDecimal.valueOf((Double) metric.get("confidence_score")) // extractionConfidenceScore
                        );
                        metricValues.add(metricValue);
                    }
                }
            }
            List<MetricValue> savedMetricValues = new ArrayList<>();
            for (MetricValue metricValue : metricValues) {
                MetricValue saved = metricValueRepository.save(metricValue);
                savedMetricValues.add(saved);
                logger.info("Saved MetricValue: {}", saved.getMetricValueId());
            }
            String message = "Data loaded successfully. Saved " + savedMetricValues.size() + " metric values.";
            logger.info(message);
            return ResponseEntity.ok(message);
        } catch (Exception e) {
            logger.error("Error loading data: {}", e.getMessage(), e);
            return ResponseEntity.badRequest().body("Error loading data: " + e.getMessage());
        }
    }




}
