# TODO List for Simplifying to metric_value Table Only

- [x] Edit MetricController.java: Remove CompanyRepository import and autowire, change GET endpoint to return List<MetricValue>, change POST endpoint to accept List<MetricValue> and save directly without Company.
- [x] Remove src/main/java/com/permian/metrics/model/Company.java
- [x] Remove src/main/java/com/permian/metrics/repository/CompanyRepository.java
- [x] Remove src/main/java/com/permian/metrics/model/MetricDefinition.java
- [x] Remove src/main/java/com/permian/metrics/repository/MetricDefinitionRepository.java
- [x] Remove src/main/java/com/permian/metrics/model/SourceDocument.java
- [x] Remove src/main/java/com/permian/metrics/repository/SourceDocumentRepository.java
- [x] Remove src/main/java/com/permian/metrics/dto/ExtractionDataDto.java
- [x] Update POST endpoint to accept Map<String, Object> for JSON parsing from extractor_output_json.json
- [x] Ensure company_id is nullable in MetricValue model
